;(function () {
  if (location.href.indexOf('vconsole') !== -1) {
    new window.VConsole()
  }
})()
