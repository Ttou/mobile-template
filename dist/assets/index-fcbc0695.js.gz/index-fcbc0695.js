import{d as e,h as t,c as s,_ as a}from"./index-f20c7d74.js";const n="view__ZbtS4",o={view:n},d=e({name:t.CATEGORY.name,render(){return s("div",{class:o.view},[a("分类")])}});export{d as default};
