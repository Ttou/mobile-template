import{d as e,h as s,c as t,_ as a}from"./index-f20c7d74.js";const n="view__07Ep-",o={view:n},d=e({name:s.CART.name,render(){return t("div",{class:o.view},[a("购物车")])}});export{d as default};
