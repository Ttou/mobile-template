import{d as e,f as s,c as t,_ as a}from"./index-52f5b0f7.js";const n="view__07Ep-",o={view:n},d=e({name:s.CART.name,render(){return t("div",{class:o.view},[a("购物车")])}});export{d as default};
