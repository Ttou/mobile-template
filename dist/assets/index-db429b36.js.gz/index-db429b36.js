import{d as e,f as n,c as s,_ as t}from"./index-52f5b0f7.js";const a="view__0-Gnh",o={view:a},d=e({name:n.MY.name,render(){return s("div",{class:o.view},[t("我的")])}});export{d as default};
