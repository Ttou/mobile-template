import{d as e,f as t,c as s,_ as a}from"./index-52f5b0f7.js";const n="view__ZbtS4",o={view:n},d=e({name:t.CATEGORY.name,render(){return s("div",{class:o.view},[a("分类")])}});export{d as default};
