import{d as e,Z as a,a as n,_ as s}from"./index.6328ae91.js";const t="view__0-Gnh",o={view:t},d=e({name:a.MY.name,render(){return n("div",{class:o.view},[s("\u6211\u7684")])}});export{d as default};
