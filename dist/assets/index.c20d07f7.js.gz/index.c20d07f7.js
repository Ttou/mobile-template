import{d as e,_ as a,a as n,$ as s}from"./index.be8f51e1.js";const t="view__0-Gnh",o={view:t},d=e({name:a.MY.name,render(){return n("div",{class:o.view},[s("\u6211\u7684")])}});export{d as default};
