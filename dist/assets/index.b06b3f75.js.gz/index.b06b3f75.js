import{d as e,_ as t,a,$ as s}from"./index.be8f51e1.js";const n="view__ZbtS4",o={view:n},d=e({name:t.CATEGORY.name,render(){return a("div",{class:o.view},[s("\u5206\u7C7B")])}});export{d as default};
