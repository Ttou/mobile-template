import{d as e,h as n,c as s,_ as t}from"./index-f20c7d74.js";const a="view__0-Gnh",o={view:a},d=e({name:n.MY.name,render(){return s("div",{class:o.view},[t("我的")])}});export{d as default};
