import{d as e,f as s,c as t,_ as a}from"./index-52f5b0f7.js";const n="view__RZcY4",o={view:n},c=e({name:s.SHOP.name,render(){return t("div",{class:o.view},[a("商铺")])}});export{c as default};
